<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Registration</title>
<link rel="stylesheet" href="css/style.css" />
</head>
<body>
<?php
require('dbconnection.php');
// If form submitted, insert values into the database.
if (isset($_REQUEST['username'])){
        // removes backslashes
 $username = stripslashes($_REQUEST['username']);
        //escapes special characters in a string
 $username = mysqli_real_escape_string($con,$username); 
 $password = stripslashes($_REQUEST['password']);
 $password = mysqli_real_escape_string($con,$password);

        $query = "INSERT into `admin` (username, password)
VALUES ('$username', '".($password)."')";
        $result = mysqli_query($con,$query);
        if($result){
            echo "<div class='form'>
<h3>admin added successfully.</h3>
<br/> <a href='manage-users.php'> GO BACK TO HOME</a></div>";
        }
    }else{
?>
<div class="form">
<h1>Add Admin</h1>
<form name="registration" action="" method="post">
<input type="text" name="username" placeholder="Username" required />
<input type="password" name="password" placeholder="Password" required />
<input  type="submit" style="backcolor:blue" name="submit" value="Add" />
</form>
</div>
<?php } ?>
</body>
<style>
input[type=text], select {
  width: 10%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}

input[type=password], select {
  width: 10%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}

input[type=submit] {
  width: 5%;
  background-color: #4CAF50;
  color: white;
  padding: 10px 10px;
  margin-left: 20px ;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

input[type=submit]:hover {
  background-color: #45a049;
}

div {
  border-radius: 5px;
  background-color: #f2f2f2;
  padding: 20px;
}

a:hover {
  background-color: yellow;
 
  text-decoration: underline;
}

a:link {
 
 
  text-decoration: underline;
}

</style>
</html>