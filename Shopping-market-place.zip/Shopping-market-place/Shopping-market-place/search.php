<?php
$servername="localhost";
$username="username";
$password="password";
$dbname="work";


$conn=mysqli_connect($servername,$username,$password,$dbname);

if(!$conn){
die("connection failed".mysqli_connect_error());
}


mysqli_close($conn);

?>


